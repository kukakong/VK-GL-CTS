# Android 构建说明

Android平台的测试程序需要使用ndk-build构建APK。已生成以下静态库：

## ARM64 (arm64-v8a)
- libdeqp-egl-package.a
- libdeqp-gles2-package.a
- libdeqp-gles3-package.a
- libdeqp-gles31-package.a

## ARM32 (armeabi-v7a)
- libdeqp-egl-package.a
- libdeqp-gles2-package.a
- libdeqp-gles3-package.a
- libdeqp-gles31-package.a

## 构建APK步骤

1. 使用Android Studio打开项目
2. 或使用命令行:
```bash
cd /path/to/VK-GL-CTS
ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=android/jni/Android.mk
ant debug
```

3. 安装APK:
```bash
adb install -r bin/NativeActivity-debug.apk
```

## 运行测试

```bash
adb shell am start -n com.drawelements.deqp/android.app.NativeActivity -e cmdLine "--deqp-caselist-file=/sdcard/testcases.txt --deqp-log-filename=/sdcard/result.qpa"
```
